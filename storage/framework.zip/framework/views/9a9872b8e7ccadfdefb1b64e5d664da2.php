<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto p-6">

    <h1 class="text-2xl font-bold mb-4">
        Edit Details: <?php echo e($product->name); ?>

    </h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST"
          action="<?php echo e(route('admin.products.details.update', $product->id)); ?>"
          enctype="multipart/form-data"
          class="bg-white shadow rounded p-6">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        

        
        

        
<div class="mb-4">
    <label class="block font-medium mb-1">Order Table (JSON - one row per line in format: Name|REF|Technology|Packaging)</label>
    <textarea name="order_table" class="w-full border rounded px-3 py-2" rows="6" placeholder="Hepatitis GPack|HEP/GPACK/100|real-time PCR|1 pc
Bloodborne GPack|BB/GPACK/100|real-time PCR|1 pc
GeneProof HBV Kit|16V/X5EX/X25|real-time PCR|25 reactions / 100 reactions"><?php echo e(old('order_table', $detail->order_table ? implode("\n", array_map(function($row) { return implode('|', $row); }, json_decode($detail->order_table, true))) : '')); ?></textarea>
    <p class="mt-1 text-sm text-gray-500">
        Format: Product Name|REF|Technology|Packaging (one per line)<br>
        Example: Hepatitis GPack|HEP/GPACK/100|real-time PCR|1 pc
    </p>
</div>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Brochure (PDF)</label>
            <input type="file" name="brochure" class="w-full border rounded px-3 py-2">
            <?php if($detail->brochure): ?>
                <p class="mt-1 text-sm text-gray-500">
                    Current: <a href="<?php echo e(asset('storage/' . $detail->brochure)); ?>" target="_blank" class="text-blue-600 hover:underline">View Brochure</a>
                </p>
            <?php endif; ?>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Image</label>
            <input type="file" name="image" class="w-full border rounded px-3 py-2">
            <?php if($detail->image): ?>
                <p class="mt-1">
                    <img src="<?php echo e(asset('storage/' . $detail->image)); ?>" alt="Image" class="h-20 w-20 object-contain border">
                </p>
            <?php endif; ?>
        </div>

        
<div class="mb-4">
    <label class="block font-medium mb-1">Second Image (Optional - appears after features)</label>
    <input type="file" name="second_image" class="w-full border rounded px-3 py-2">
    <?php if($detail->second_image): ?>
        <p class="mt-1">
            <img src="<?php echo e(asset('storage/' . $detail->second_image)); ?>" alt="Second Image" class="h-20 w-20 object-contain border">
        </p>
    <?php endif; ?>
</div>

        
        

        

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
            Update Details
        </button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/products/details/edit.blade.php ENDPATH**/ ?>