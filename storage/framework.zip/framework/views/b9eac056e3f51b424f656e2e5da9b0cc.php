<?php $__env->startSection('title', 'Add Menu'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <h1 class="text-2xl font-bold mb-4">Add New Menu</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 p-2 rounded mb-4">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<form action="<?php echo e(route('admin.menus.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-4">
            <label for="name" class="block font-medium text-gray-700">Menu Name</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required
                   class="w-full border rounded px-3 py-2">
        </div>

        
        <div class="mb-4">
            <label for="parent_id" class="block font-medium text-gray-700">Parent Menu (optional)</label>
            <select name="parent_id" id="parent_id" class="w-full border rounded px-3 py-2">
                <option value="">-- Top-level Menu --</option>
                <?php $__currentLoopData = $menus->where('parent_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($menu->id); ?>" <?php echo e(old('parent_id') == $menu->id ? 'selected' : ''); ?>>
                        <?php echo e($menu->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-4">
            <label for="order" class="block font-medium text-gray-700">Order</label>
            <input type="number" name="order" id="order" value="<?php echo e(old('order', 0)); ?>"
                   class="w-full border rounded px-3 py-2">
        </div>

        
        <div class="mb-4">
            <label for="status" class="block font-medium text-gray-700">Status</label>
            <select name="status" id="status" class="w-full border rounded px-3 py-2">
                <option value="1" <?php echo e(old('status',1) == 1 ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e(old('status') == 0 ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Create Menu</button>
        <a href="<?php echo e(route('admin.menus.index')); ?>" class="ml-2 px-4 py-2 rounded border">Cancel</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/menus/create.blade.php ENDPATH**/ ?>