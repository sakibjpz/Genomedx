<?php $__env->startSection('title', 'Query Types Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 gap-3">
        <h1 class="text-xl sm:text-2xl font-bold">Query Types Management</h1>
        <a href="<?php echo e(route('admin.query-types.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-center text-sm sm:text-base">
            <i class="fas fa-plus mr-2"></i>Add Query Type
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Desktop Table View -->
    <div class="hidden md:block bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sort</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Query Type</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="sortable">
                    <?php $__currentLoopData = $queryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queryType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id="<?php echo e($queryType->id); ?>" class="hover:bg-gray-50 cursor-move">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <i class="fas fa-grip-vertical text-gray-400"></i>
                            <span class="text-sm text-gray-500 ml-2"><?php echo e($queryType->sort_order); ?></span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($queryType->display_name); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($queryType->name); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                <?php echo e($queryType->team->name == 'Sales' ? 'bg-green-100 text-green-800' : 
                                   ($queryType->team->name == 'Technical Support' ? 'bg-yellow-100 text-yellow-800' : 
                                   'bg-blue-100 text-blue-800')); ?>">
                                <?php echo e($queryType->team->name); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="text-sm text-gray-700 max-w-xs truncate"><?php echo e($queryType->description); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                <?php echo e($queryType->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                <?php echo e($queryType->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php echo e($queryType->queries->count()); ?> queries
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <a href="<?php echo e(route('admin.query-types.edit', $queryType->id)); ?>" 
                               class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.query-types.destroy', $queryType->id)); ?>" 
                                  method="POST" class="inline" 
                                  onsubmit="return confirm('Delete this query type?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-900">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Mobile Card View -->
    <div class="md:hidden space-y-4" id="sortable-mobile">
        <?php $__currentLoopData = $queryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queryType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div data-id="<?php echo e($queryType->id); ?>" class="bg-white rounded-lg shadow p-4">
            <!-- Drag Handle & Sort Order -->
            <div class="flex items-center justify-between mb-3 pb-3 border-b">
                <div class="flex items-center">
                    <i class="fas fa-grip-vertical text-gray-400 text-lg mr-3 cursor-move"></i>
                    <div>
                        <h3 class="text-base font-semibold text-gray-900"><?php echo e($queryType->display_name); ?></h3>
                        <p class="text-xs text-gray-500"><?php echo e($queryType->name); ?></p>
                    </div>
                </div>
                <span class="text-xs font-medium text-gray-500 bg-gray-100 px-2 py-1 rounded">#<?php echo e($queryType->sort_order); ?></span>
            </div>

            <!-- Info Grid -->
            <div class="space-y-2 mb-4">
                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-600 font-medium">Team:</span>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                        <?php echo e($queryType->team->name == 'Sales' ? 'bg-green-100 text-green-800' : 
                           ($queryType->team->name == 'Technical Support' ? 'bg-yellow-100 text-yellow-800' : 
                           'bg-blue-100 text-blue-800')); ?>">
                        <?php echo e($queryType->team->name); ?>

                    </span>
                </div>

                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-600 font-medium">Status:</span>
                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                        <?php echo e($queryType->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                        <?php echo e($queryType->is_active ? 'Active' : 'Inactive'); ?>

                    </span>
                </div>

                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-600 font-medium">Usage:</span>
                    <span class="text-xs text-gray-900 font-medium"><?php echo e($queryType->queries->count()); ?> queries</span>
                </div>

                <?php if($queryType->description): ?>
                <div class="pt-2 border-t">
                    <p class="text-xs text-gray-600 font-medium mb-1">Description:</p>
                    <p class="text-sm text-gray-700"><?php echo e($queryType->description); ?></p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Action Buttons -->
            <div class="flex gap-2 pt-3 border-t">
                <a href="<?php echo e(route('admin.query-types.edit', $queryType->id)); ?>" 
                   class="flex-1 text-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition">
                    <i class="fas fa-edit mr-1"></i> Edit
                </a>
                <form action="<?php echo e(route('admin.query-types.destroy', $queryType->id)); ?>" 
                      method="POST" class="flex-1" 
                      onsubmit="return confirm('Delete this query type?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="w-full px-4 py-2 bg-red-600 text-white text-sm font-medium rounded hover:bg-red-700 transition">
                        <i class="fas fa-trash mr-1"></i> Delete
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6">
        <?php echo e($queryTypes->links()); ?>

    </div>
</div>

<!-- Sortable JS -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.14.0/Sortable.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Desktop sortable
        const sortable = document.getElementById('sortable');
        
        if (sortable) {
            new Sortable(sortable, {
                animation: 150,
                handle: '.fa-grip-vertical',
                onEnd: function(evt) {
                    const order = [];
                    document.querySelectorAll('#sortable tr').forEach((row, index) => {
                        order.push(row.getAttribute('data-id'));
                    });

                    // Send AJAX request to update order
                    fetch('<?php echo e(route("admin.query-types.reorder")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ order: order })
                    });
                }
            });
        }

        // Mobile sortable
        const sortableMobile = document.getElementById('sortable-mobile');
        
        if (sortableMobile) {
            new Sortable(sortableMobile, {
                animation: 150,
                handle: '.fa-grip-vertical',
                onEnd: function(evt) {
                    const order = [];
                    document.querySelectorAll('#sortable-mobile > div').forEach((card, index) => {
                        order.push(card.getAttribute('data-id'));
                    });

                    // Send AJAX request to update order
                    fetch('<?php echo e(route("admin.query-types.reorder")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ order: order })
                    });
                }
            });
        }
    });
</script>

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* Mobile specific adjustments */
    @media (max-width: 767px) {
        .container {
            padding-left: 0.75rem;
            padding-right: 0.75rem;
        }
    }

    /* Sortable ghost styling */
    .sortable-ghost {
        opacity: 0.4;
        background: #f3f4f6;
    }

    /* Mobile drag handle visibility */
    @media (max-width: 767px) {
        .fa-grip-vertical {
            cursor: grab;
        }
        
        .fa-grip-vertical:active {
            cursor: grabbing;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/query-types/index.blade.php ENDPATH**/ ?>