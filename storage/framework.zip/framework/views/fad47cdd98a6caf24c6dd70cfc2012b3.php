<div class="space-y-6">
    <!-- Title -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Title *</label>
        <input type="text" 
               name="title" 
               value="<?php echo e(old('title', $news->title ?? '')); ?>" 
               class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
               required>
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Excerpt -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Excerpt (Short Description)</label>
        <textarea name="excerpt" 
                  rows="3" 
                  class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('excerpt', $news->excerpt ?? '')); ?></textarea>
        <p class="mt-1 text-sm text-gray-500">Brief summary shown on news cards (max 500 chars)</p>
        <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Content -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Content</label>
        <textarea name="content" 
                  rows="6" 
                  class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('content', $news->content ?? '')); ?></textarea>
        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Image Upload -->
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Featured Image</label>
        
        <?php if(isset($news) && $news->image): ?>
            <div class="mb-4">
                <img src="<?php echo e(asset('storage/' . $news->image)); ?>" 
                     alt="Current image" 
                     class="w-64 h-48 object-cover rounded-lg mb-2">
                <p class="text-sm text-gray-600">Current image</p>
            </div>
        <?php endif; ?>
        
        <input type="file" 
               name="image" 
               accept="image/*"
               class="w-full border border-gray-300 rounded-lg p-2">
        <p class="mt-1 text-sm text-gray-500">Upload JPG, PNG, GIF (max 2MB)</p>
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Category & Date Row -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Category -->
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Category *</label>
            <select name="category" 
                    class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required>
                <option value="news" <?php echo e(old('category', $news->category ?? '') == 'news' ? 'selected' : ''); ?>>News</option>
                <option value="event" <?php echo e(old('category', $news->category ?? '') == 'event' ? 'selected' : ''); ?>>Event</option>
                <option value="update" <?php echo e(old('category', $news->category ?? '') == 'update' ? 'selected' : ''); ?>>Update</option>
                <option value="achievement" <?php echo e(old('category', $news->category ?? '') == 'achievement' ? 'selected' : ''); ?>>Achievement</option>
            </select>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Published Date -->
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Published Date *</label>
            <input type="date" 
                   name="published_date" 
                   value="<?php echo e(old('published_date', isset($news) ? $news->published_date->format('Y-m-d') : date('Y-m-d'))); ?>"
                   class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   required>
            <?php $__errorArgs = ['published_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <!-- Status & Sort Order Row -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Status -->
        <div>
            <label class="flex items-center space-x-3">
                <input type="checkbox" 
                       name="is_published" 
                       value="1"
                       <?php echo e(old('is_published', isset($news) ? $news->is_published : true) ? 'checked' : ''); ?>

                       class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                <span class="text-sm font-medium text-gray-700">Publish this news</span>
            </label>
        </div>

        <!-- Sort Order -->
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Sort Order</label>
            <input type="number" 
                   name="sort_order" 
                   value="<?php echo e(old('sort_order', $news->sort_order ?? 0)); ?>"
                   class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            <p class="mt-1 text-sm text-gray-500">Lower numbers appear first</p>
            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/news/form.blade.php ENDPATH**/ ?>