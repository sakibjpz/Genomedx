<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto p-6">

    <h1 class="text-2xl font-bold mb-4">
        Products in: <?php echo e($productGroup->name); ?>

    </h1>

    
    <div class="bg-white shadow rounded p-4 mb-6">
        <form method="POST"
              action="<?php echo e(route('admin.product-groups.products.store', $productGroup)); ?>"
              enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                
                <div>
                    <label class="block font-medium">Product Name</label>
                    <input type="text" name="name" class="w-full border rounded px-3 py-2" required>
                </div>

                
                <div>
                    <label class="block font-medium">Product Image (Icon)</label>
                    <input type="file" name="image" class="w-full border rounded px-3 py-2" required>
                </div>

                
                <div>
                    <label class="block font-medium">Badge (Optional)</label>
                    <input type="text" name="badge" class="w-full border rounded px-3 py-2" placeholder="e.g., NEW, BEST SELLER">
                </div>

                
                <div>
                    <label class="block font-medium">Position</label>
                    <input type="number" name="position" class="w-full border rounded px-3 py-2" value="0">
                </div>

                
                <div class="flex items-center mt-2">
                    <input type="checkbox" name="status" value="1" class="mr-2" checked>
                    <label>Active</label>
                </div>

            </div>

            <button class="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Add Product
            </button>
        </form>
    </div>

    
    <div class="bg-white shadow rounded p-4">
        <table class="w-full border">
            <thead>
                <tr class="bg-gray-100">
                    <th class="p-2 text-left">Image</th>
                    <th class="p-2 text-left">Name</th>
                    <th class="p-2 text-left">Badge</th>
                    <th class="p-2 text-center">Status</th>
                    <th class="p-2 text-center">Position</th>
                    <th class="p-2 text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="p-2">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="h-10 w-10 object-contain">
                            <?php endif; ?>
                        </td>
                        <td class="p-2"><?php echo e($product->name); ?></td>
                        <td class="p-2"><?php echo e($product->badge ?? '-'); ?></td>
                        <td class="p-2 text-center">
                            <?php echo e($product->status ? 'Active' : 'Inactive'); ?>

                        </td>
                        <td class="p-2 text-center">
                            <?php echo e($product->position); ?>

                        </td>
                        <td class="p-2 text-center space-x-2">
                            
                            <a href="<?php echo e(route('admin.product-groups.products.edit', [$productGroup->id, $product->id])); ?>"
                               class="text-blue-600 hover:underline">Edit</a>

                            
                            <a href="<?php echo e(route('admin.products.details.edit', $product->id)); ?>"
   class="text-green-600 hover:underline">Edit Details</a>

                            
                            <form action="<?php echo e(route('admin.product-groups.products.destroy', [$productGroup->id, $product->id])); ?>" method="POST" class="inline-block" onsubmit="return confirm('Are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="p-4 text-center text-gray-500">
                            No products yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/products/index.blade.php ENDPATH**/ ?>