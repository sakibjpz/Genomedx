<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">

    <h1 class="text-2xl font-bold mb-6">Edit Product Group</h1>

    
    <?php if(session('success')): ?>
        <div class="mb-4 p-3 bg-green-100 text-green-800 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="mb-4 p-3 bg-red-100 text-red-800 rounded">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white p-6 rounded shadow mb-8">
       <form method="POST" action="<?php echo e(route('admin.product-groups.update', $productGroup->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                
                <div>
                    <label class="block text-sm font-medium mb-1">Name</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $productGroup->name)); ?>" class="w-full border rounded p-2" required>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Color</label>
                    <select name="color" class="w-full border rounded p-2">
                        <?php
                            $colors = [
                                'red-500' => 'Red',
                                'green-500' => 'Green',
                                'blue-500' => 'Blue',
                                'orange-500' => 'Orange',
                                'purple-600' => 'Purple',
                                'cyan-500' => 'Cyan',
                                'lime-500' => 'Lime',
                                'amber-700' => 'Amber',
                                'gray-400' => 'Gray',
                            ];
                        ?>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e($productGroup->color == $key ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Icon</label>
                    <input type="file" name="icon" accept=".svg,.png" class="w-full border rounded p-2">
                    <?php if($productGroup->icon): ?>
                        <img src="<?php echo e(asset('storage/'.$productGroup->icon)); ?>" alt="Icon" class="w-12 h-12 mt-2">
                    <?php endif; ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Position</label>
                    <input type="number" name="position" value="<?php echo e(old('position', $productGroup->position)); ?>" class="w-full border rounded p-2">
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Company</label>
                    <select name="company_id" class="w-full border rounded p-2">
                        <option value="">-- No Company --</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>" 
                                <?php echo e(old('company_id', $productGroup->company_id) == $company->id ? 'selected' : ''); ?>>
                                <?php echo e($company->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="flex items-center mt-6">
                    <input type="checkbox" name="status" value="1" class="mr-2" <?php echo e($productGroup->status ? 'checked' : ''); ?>>
                    <label>Active</label>
                </div>

            </div>

            
            <div class="flex space-x-3 mt-4">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Update Group
                </button>
                <a href="<?php echo e(route('admin.product-groups.index')); ?>" 
                   class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">
                    Cancel
                </a>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/product-groups/edit.blade.php ENDPATH**/ ?>