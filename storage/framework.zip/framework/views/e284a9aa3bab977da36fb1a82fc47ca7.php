<?php $__env->startSection('title', 'Edit Banner'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <h1 class="text-2xl font-bold mb-4">Edit Banner</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 p-2 rounded mb-4">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.banners.update', $banner->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-4">
            <label for="title" class="block font-semibold mb-1">Banner Title</label>
            <textarea name="title" id="title" class="w-full border p-2 rounded" rows="3" required><?php echo e(old('title', $banner->title)); ?></textarea>
        </div>

        
        <div class="mb-4">
            <label for="subtitle" class="block font-semibold mb-1">Banner Subtitle</label>
            <textarea name="subtitle" id="subtitle" class="w-full border p-2 rounded" rows="2"><?php echo e(old('subtitle', $banner->subtitle)); ?></textarea>
        </div>

        
        <div class="mb-4">
            <label for="image" class="block font-semibold mb-1">Banner Image</label>
            <input type="file" name="image" id="image" class="w-full border p-2 rounded">
            <?php if($banner->image): ?>
                <div class="mt-2">
                    <img src="<?php echo e(asset('images/'.$banner->image)); ?>" alt="Banner" class="w-48 h-24 object-cover rounded border">
                </div>
            <?php endif; ?>
            <small class="text-gray-500">Leave blank to keep current image. Allowed: jpg, jpeg, png, svg</small>
        </div>

        
        <div class="mb-4">
            <label for="button_text" class="block font-semibold mb-1">Button Text</label>
            <input type="text" name="button_text" id="button_text" class="w-full border p-2 rounded" value="<?php echo e(old('button_text', $banner->button_text)); ?>">
        </div>

        
        <div class="mb-4">
            <label for="button_url" class="block font-semibold mb-1">Button URL</label>
            <input type="url" name="button_url" id="button_url" class="w-full border p-2 rounded" value="<?php echo e(old('button_url', $banner->button_url)); ?>">
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
        <a href="<?php echo e(route('admin.banners.index')); ?>" class="ml-2 px-4 py-2 rounded border">Cancel</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/banners/edit.blade.php ENDPATH**/ ?>