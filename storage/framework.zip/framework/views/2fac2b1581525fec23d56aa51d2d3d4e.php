<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 py-8">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        
        
        <div class="mb-8">
            <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
                Search Results for "<?php echo e($query); ?>"
            </h1>
            <p class="text-gray-600">
                Found <?php echo e($products->count()); ?> product(s)
            </p>
        </div>

        
        <?php if($products->count() > 0): ?>
            <div class="space-y-8">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <div class="p-6">
                            
                            <div class="flex items-start space-x-4">
                                <?php if($product->image || $product->image_path): ?>
                                    <?php
                                        $path = $product->image ?? $product->image_path;
                                        $isAsset = str_contains($path, 'assets/');
                                    ?>
                                    <div class="flex-shrink-0 w-24 h-24">
                                        <img src="<?php echo e($isAsset ? asset($path) : asset('storage/' . $path)); ?>" 
                                             alt="<?php echo e($product->name); ?>"
                                             class="w-full h-full object-contain">
                                    </div>
                                <?php endif; ?>
                                
                                <div class="flex-1">
                                    <h3 class="font-bold text-xl text-gray-800 mb-2">
                                        <a href="<?php echo e(route('products.show', $product)); ?>" 
                                           class="hover:text-blue-600">
                                            <?php echo e($product->name); ?>

                                        </a>
                                    </h3>
                                    
                                    <?php if($product->productGroup): ?>
                                        <div class="mb-3">
                                            <span class="inline-block bg-blue-100 text-blue-700 text-sm px-3 py-1 rounded font-medium">
                                                <?php echo e($product->productGroup->name); ?>

                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if($product->short_description): ?>
                                        <p class="text-gray-600">
                                            <?php echo e($product->short_description); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            
                            <?php if($product->productGroup): ?>
                                <?php
                                    $relatedProducts = $product->productGroup->products()
                                        ->where('id', '!=', $product->id)
                                        ->where('status', 1)
                                        ->limit(4)
                                        ->get();
                                ?>
                                
                                <?php if($relatedProducts->count() > 0): ?>
                                    <div class="mt-8 pt-6 border-t">
                                        <h4 class="font-bold text-gray-700 mb-4">
                                            Other products in <?php echo e($product->productGroup->name); ?>

                                        </h4>
                                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                                            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('products.show', $related)); ?>"
                                                   class="border border-gray-200 rounded p-3 hover:bg-gray-50 transition">
                                                    <div class="font-medium text-gray-800 text-sm">
                                                        <?php echo e($related->name); ?>

                                                    </div>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow p-8 text-center">
                <div class="text-5xl mb-4 text-gray-400">🔍</div>
                <h3 class="text-xl font-bold text-gray-700 mb-2">No products found</h3>
                <p class="text-gray-600 mb-6">Try different search terms</p>
                <a href="<?php echo e(url('/')); ?>" class="text-blue-600 hover:text-blue-800 font-medium">
                    ← Back to Home
                </a>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.inner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/front/products/search-results.blade.php ENDPATH**/ ?>