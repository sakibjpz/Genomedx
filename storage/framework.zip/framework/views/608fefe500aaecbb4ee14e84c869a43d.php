<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">

    <h1 class="text-2xl font-bold mb-6">
        Add Product to "<?php echo e($productGroup->name); ?>"
    </h1>

    
    <?php if($errors->any()): ?>
        <div class="mb-4 p-3 bg-red-100 text-red-800 rounded">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="bg-white p-6 rounded shadow">
       <form method="POST" action="<?php echo e(route('admin.product-groups.products.store', $productGroup->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                
                <div>
                    <label class="block text-sm font-medium mb-1">Product Name</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full border rounded p-2" required>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Product Image (Icon)</label>
                    <input type="file" name="image" accept=".jpg,.jpeg,.png,.svg" class="w-full border rounded p-2" required>
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Badge (Optional)</label>
                    <input type="text" name="badge" value="<?php echo e(old('badge')); ?>" class="w-full border rounded p-2" placeholder="e.g., NEW, BEST SELLER">
                </div>

                
                <div>
                    <label class="block text-sm font-medium mb-1">Position</label>
                    <input type="number" name="position" value="<?php echo e(old('position', 0)); ?>" class="w-full border rounded p-2">
                </div>

                
                <div class="flex items-center mt-6">
                    <input type="checkbox" name="status" value="1" class="mr-2" checked>
                    <label>Active</label>
                </div>

            </div>

            <button type="submit" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
                Add Product
            </button>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/products/create.blade.php ENDPATH**/ ?>