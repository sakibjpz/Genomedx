<?php $__env->startSection('title', $news->title . ' - GenomeDX'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <!-- Back Button -->
        <div class="mb-6">
            <a href="<?php echo e(url('/')); ?>" 
               class="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium text-sm transition">
                <i class="fas fa-arrow-left mr-2"></i> Back to Home
            </a>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column - Main Article -->
            <article class="lg:col-span-2">
                <!-- Title -->
                <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 leading-tight">
                    <?php echo e($news->title); ?>

                </h1>

                <!-- Date -->
                <time class="inline-block text-sm text-gray-600 mb-6">
                    <?php echo e($news->published_date->format('d/m/Y')); ?>

                </time>

                <!-- News Image -->
                <div class="relative mb-8 rounded-lg overflow-hidden shadow-md">
                    <?php if($news->image): ?>
                        <img src="<?php echo e(asset('storage/' . $news->image)); ?>" 
                             alt="<?php echo e($news->title); ?>"
                             class="w-full h-auto object-cover">
                    <?php else: ?>
                        <div class="w-full h-96 bg-gradient-to-br from-purple-200 via-blue-200 to-purple-300 flex items-center justify-center">
                            <i class="fas fa-newspaper text-gray-400 text-8xl"></i>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Excerpt -->
                <?php if($news->excerpt): ?>
                    <div class="mb-6">
                        <p class="text-lg md:text-xl text-gray-800 font-medium leading-relaxed">
                            <?php echo e($news->excerpt); ?>

                        </p>
                    </div>
                <?php endif; ?>

                <!-- Content -->
                <?php if($news->content): ?>
                    <div class="text-gray-700 text-base md:text-lg leading-relaxed space-y-4 mb-8">
                        <?php echo nl2br(e($news->content)); ?>

                    </div>
                <?php else: ?>
                    <div class="text-center py-12 text-gray-500">
                        <i class="fas fa-file-alt text-4xl mb-4"></i>
                        <p>Full content coming soon...</p>
                    </div>
                <?php endif; ?>

                <!-- Share Buttons -->
                <div class="mt-8 pt-6 border-t border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Share this article:</h3>
                    <div class="flex space-x-3">
                        <a href="#" 
                           onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(window.location.href), 'facebook-share', 'width=580,height=296'); return false;"
                           class="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition shadow-md">
                            <i class="fab fa-facebook-f text-sm"></i>
                        </a>
                        
                        <a href="#" 
                           onclick="window.open('https://www.linkedin.com/shareArticle?mini=true&url='+encodeURIComponent(window.location.href)+'&title='+encodeURIComponent('<?php echo e($news->title); ?>'), 'linkedin-share', 'width=600,height=400'); return false;"
                           class="w-10 h-10 bg-blue-700 text-white rounded-full flex items-center justify-center hover:bg-blue-800 transition shadow-md">
                            <i class="fab fa-linkedin-in text-sm"></i>
                        </a>
                        <a href="mailto:?subject=<?php echo e(urlencode($news->title)); ?>&body=<?php echo e(urlencode('Check out this article: ' . url()->current())); ?>" 
                           class="w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition shadow-md">
                            <i class="fas fa-envelope text-sm"></i>
                        </a>
                    </div>
                </div>
            </article>

            <!-- Right Column - Related News Sidebar -->
            <?php if($relatedNews->count() > 0): ?>
                <aside class="lg:col-span-1">
                    <div class="bg-white rounded-lg shadow-md p-6 sticky top-8">
                        <h2 class="text-xl md:text-2xl font-bold text-gray-900 mb-6 pb-3 border-b border-gray-200">
                            Related News
                        </h2>
                        
                        <div class="space-y-6">
                            <?php $__currentLoopData = $relatedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="group">
                                    <?php if($related->image): ?>
                                        <a href="<?php echo e(route('news.show', $related)); ?>" class="block mb-3 rounded-lg overflow-hidden">
                                            <img src="<?php echo e(asset('storage/' . $related->image)); ?>" 
                                                 alt="<?php echo e($related->title); ?>"
                                                 class="w-full h-40 object-cover group-hover:scale-105 transition duration-300">
                                        </a>
                                    <?php endif; ?>
                                    
                                    <span class="inline-block px-3 py-1 text-xs font-semibold text-white rounded-full <?php echo e($related->categoryColor); ?> mb-2">
                                        <?php echo e($related->categoryLabel); ?>

                                    </span>
                                    
                                    <h3 class="text-base font-bold text-gray-900 mb-2 leading-snug">
                                        <a href="<?php echo e(route('news.show', $related)); ?>" 
                                           class="hover:text-blue-600 transition line-clamp-2">
                                            <?php echo e($related->title); ?>

                                        </a>
                                    </h3>
                                    
                                    <time class="text-xs text-gray-500 block">
                                        <i class="fas fa-calendar-alt mr-1"></i>
                                        <?php echo e($related->published_date->format('d/m/Y')); ?>

                                    </time>

                                    <?php if(!$loop->last): ?>
                                        <div class="mt-6 pt-6 border-t border-gray-100"></div>
                                    <?php endif; ?>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </aside>
            <?php endif; ?>
        </div>

        <!-- Related News Mobile/Desktop Grid (Below Article) -->
        <?php if($relatedNews->count() > 3): ?>
            <div class="mt-16">
                <h2 class="text-2xl md:text-3xl font-bold text-gray-900 mb-8">More Related News</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $relatedNews->skip(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition group">
                            <?php if($related->image): ?>
                                <a href="<?php echo e(route('news.show', $related)); ?>">
                                    <img src="<?php echo e(asset('storage/' . $related->image)); ?>" 
                                         alt="<?php echo e($related->title); ?>"
                                         class="w-full h-48 object-cover group-hover:scale-105 transition duration-300">
                                </a>
                            <?php endif; ?>
                            
                            <div class="p-5">
                                <span class="inline-block px-3 py-1 text-xs font-semibold text-white rounded-full <?php echo e($related->categoryColor); ?> mb-3">
                                    <?php echo e($related->categoryLabel); ?>

                                </span>
                                
                                <h3 class="text-lg font-bold text-gray-900 mb-2 leading-snug">
                                    <a href="<?php echo e(route('news.show', $related)); ?>" 
                                       class="hover:text-blue-600 transition line-clamp-2">
                                        <?php echo e($related->title); ?>

                                    </a>
                                </h3>
                                
                                <time class="text-sm text-gray-500">
                                    <i class="fas fa-calendar-alt mr-1"></i>
                                    <?php echo e($related->published_date->format('M d, Y')); ?>

                                </time>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.inner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/front/news/show.blade.php ENDPATH**/ ?>