<?php $__env->startSection('title', 'Add Social Link'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <h1 class="text-2xl font-bold mb-4">Add New Social Link</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 p-2 rounded mb-4">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.social-links.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-4">
            <label class="block font-semibold mb-2">Select Icon</label>
            
            <div class="flex flex-wrap gap-2 mb-2">
                <?php
                    $icons = [
                        'fab fa-facebook-f' => 'Facebook',
                        'fab fa-twitter' => 'Twitter',
                        'fab fa-linkedin-in' => 'LinkedIn',
                        'fab fa-youtube' => 'YouTube',
                        'fab fa-instagram' => 'Instagram',
                    ];
                ?>

                <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button"
                            class="icon-btn border p-2 rounded text-gray-600 hover:text-blue-600"
                            data-icon="<?php echo e($class); ?>">
                        <i class="<?php echo e($class); ?> fa-lg"></i>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <input type="hidden" name="icon" id="icon" value="<?php echo e(old('icon')); ?>">
            <small class="text-gray-500">Click an icon to select it</small>
        </div>

        <div class="mb-4">
    <label for="platform" class="block font-semibold mb-1">Platform</label>
    <select name="platform" id="platform" class="w-full border p-2 rounded" required>
        <option value="">-- Select Platform --</option>
        <option value="Facebook" <?php echo e(old('platform') == 'Facebook' ? 'selected' : ''); ?>>Facebook</option>
        <option value="Twitter" <?php echo e(old('platform') == 'Twitter' ? 'selected' : ''); ?>>Twitter</option>
        <option value="LinkedIn" <?php echo e(old('platform') == 'LinkedIn' ? 'selected' : ''); ?>>LinkedIn</option>
        <option value="YouTube" <?php echo e(old('platform') == 'YouTube' ? 'selected' : ''); ?>>YouTube</option>
        <option value="Instagram" <?php echo e(old('platform') == 'Instagram' ? 'selected' : ''); ?>>Instagram</option>
    </select>
</div>


        
        <div class="mb-4">
            <label for="url" class="block font-semibold mb-1">URL</label>
            <input type="url" name="url" id="url" class="w-full border p-2 rounded" value="<?php echo e(old('url')); ?>" required>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Create</button>
        <a href="<?php echo e(route('admin.social-links.index')); ?>" class="ml-2 px-4 py-2 rounded border">Cancel</a>
    </form>

</div>


<script>
    const buttons = document.querySelectorAll('.icon-btn');
    const iconInput = document.getElementById('icon');

    buttons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active classes from all buttons
            buttons.forEach(b => b.classList.remove('bg-blue-100', 'border-blue-500'));
            
            // Add active class to clicked button
            btn.classList.add('bg-blue-100', 'border-blue-500');

            // Set hidden input value
            iconInput.value = btn.getAttribute('data-icon');
        });

        // Pre-select if old value exists
        if(iconInput.value === btn.getAttribute('data-icon')) {
            btn.classList.add('bg-blue-100', 'border-blue-500');
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/social-links/create.blade.php ENDPATH**/ ?>