<?php $__env->startSection('title', 'Edit Company'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4 max-w-2xl">
    <div class="mb-6">
        <a href="<?php echo e(route('admin.companies.index')); ?>" class="text-blue-600 hover:text-blue-800">
            ← Back to companies
        </a>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <h1 class="text-2xl font-bold text-gray-900 mb-6">Edit Company</h1>

        <form action="<?php echo e(route('admin.companies.update', $company->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Name -->
            <div class="mb-6">
                <label for="name" class="block text-gray-700 font-medium mb-2">
                    Company Name *
                </label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name', $company->name)); ?>" required
                       class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Slug -->
            <div class="mb-6">
                <label for="slug" class="block text-gray-700 font-medium mb-2">
                    URL Slug *
                </label>
                <input type="text" id="slug" name="slug" value="<?php echo e(old('slug', $company->slug)); ?>" required
                       class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <p class="text-sm text-gray-500 mt-1">
                    Used in URLs (lowercase, hyphens, no spaces).
                </p>
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Company Image -->
<div class="mb-6">
    <label for="image" class="block text-gray-700 font-medium mb-2">
        Company Image
    </label>
    
    <!-- Current Image Preview -->
    <?php if($company->image): ?>
        <div class="mb-4">
            <img src="<?php echo e(asset('storage/' . $company->image)); ?>" 
                 alt="<?php echo e($company->name); ?>" 
                 class="w-32 h-32 object-cover rounded-lg border">
            <p class="text-sm text-gray-500 mt-1">Current image</p>
        </div>
    <?php endif; ?>
    
    <input type="file" id="image" name="image" 
           class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500">
    <p class="text-sm text-gray-500 mt-1">
        Upload company logo or image (JPG, PNG, GIF, max 2MB)
    </p>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

            <!-- Sort Order -->
            <div class="mb-6">
                <label for="sort_order" class="block text-gray-700 font-medium mb-2">
                    Sort Order
                </label>
                <input type="number" id="sort_order" name="sort_order" 
                       value="<?php echo e(old('sort_order', $company->sort_order)); ?>"
                       class="w-32 border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <!-- Active Status -->
            <div class="mb-8">
                <div class="flex items-center">
                    <input type="checkbox" id="is_active" name="is_active" value="1" 
                           class="h-4 w-4 text-blue-600" 
                           <?php echo e($company->is_active ? 'checked' : ''); ?>>
                    <label for="is_active" class="ml-2 text-gray-700 font-medium">
                        Active (show in menu)
                    </label>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="flex justify-end space-x-4">
                <a href="<?php echo e(route('admin.companies.index')); ?>" 
                   class="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                    Cancel
                </a>
                <button type="submit" 
                        class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                    Update Company
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const slugInput = document.getElementById('slug');
    
    if (nameInput && slugInput) {
        nameInput.addEventListener('input', function() {
            if (!slugInput.dataset.manuallyEdited) {
                const slug = this.value
                    .toLowerCase()
                    .replace(/[^a-z0-9\s-]/g, '') // Remove special chars
                    .replace(/\s+/g, '-')         // Replace spaces with hyphens
                    .replace(/-+/g, '-')          // Remove duplicate hyphens
                    .trim();
                slugInput.value = slug;
            }
        });
        
        // Track manual edits to slug
        slugInput.addEventListener('input', function() {
            this.dataset.manuallyEdited = 'true';
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/companies/edit.blade.php ENDPATH**/ ?>