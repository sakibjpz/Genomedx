<?php $__env->startSection('title', 'Edit Flag'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <h1 class="text-2xl font-bold mb-4">Edit Flag</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 p-2 rounded mb-4">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.flags.update', $flag->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="name" class="block font-semibold mb-1">Flag Name</label>
            <input type="text" name="name" id="name" class="w-full border p-2 rounded" value="<?php echo e(old('name', $flag->name)); ?>" required>
        </div>

        <div class="mb-4">
            <label for="image" class="block font-semibold mb-1">Flag Image</label>
            <input type="file" name="image" id="image" class="w-full border p-2 rounded">
            <?php if($flag->image): ?>
                <div class="mt-2">
                    <img src="<?php echo e(asset('storage/flags/'.$flag->image)); ?>" alt="<?php echo e($flag->name); ?>" class="w-20 h-12 object-cover">
                </div>
            <?php endif; ?>
            <small class="text-gray-500">Leave blank to keep current image</small>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
        <a href="<?php echo e(route('admin.flags.index')); ?>" class="ml-2 px-4 py-2 rounded border">Cancel</a>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/flags/edit.blade.php ENDPATH**/ ?>