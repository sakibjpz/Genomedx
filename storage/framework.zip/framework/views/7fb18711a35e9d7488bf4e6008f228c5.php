<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800"><?php echo e($company->name); ?></h1>
    <p class="text-gray-600 mt-2">Company page loaded successfully!</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/companies/show.blade.php ENDPATH**/ ?>