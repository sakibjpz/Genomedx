<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-gray-500 font-semibold">Menus</h3>
        <p class="text-2xl font-bold mt-2"><?php echo e($menusCount ?? 0); ?></p>
    </div>

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-gray-500 font-semibold">Social Links</h3>
        <p class="text-2xl font-bold mt-2"><?php echo e($socialLinksCount ?? 0); ?></p>
    </div>

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-gray-500 font-semibold">Flags</h3>
        <p class="text-2xl font-bold mt-2"><?php echo e($flagsCount ?? 0); ?></p>
    </div>

    
    <div class="bg-white p-6 rounded-lg shadow">
        <h3 class="text-gray-500 font-semibold">Banners</h3>
        <p class="text-2xl font-bold mt-2"><?php echo e($bannersCount ?? 0); ?></p>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>