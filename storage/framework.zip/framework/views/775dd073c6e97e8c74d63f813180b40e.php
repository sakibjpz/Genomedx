<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="md:flex md:items-center md:justify-between mb-6">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Documents for: <?php echo e($product->name); ?>

                </h2>
                <div class="mt-1 flex flex-col sm:flex-row sm:flex-wrap sm:mt-0 sm:space-x-6">
                    <div class="mt-2 flex items-center text-sm text-gray-500">
                        <span class="mr-2">Product:</span>
                        <span class="font-medium"><?php echo e($product->name); ?></span>
                    </div>
                    <div class="mt-2 flex items-center text-sm text-gray-500">
                        <span class="mr-2">Documents:</span>
                        <span class="font-medium"><?php echo e($documents->count()); ?></span>
                    </div>
                </div>
            </div>
            <div class="mt-4 flex md:mt-0 md:ml-4 space-x-3">
                <a href="<?php echo e(route('admin.product-groups.products.edit', [$product->productGroup, $product->id])); ?>"
                   class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Back to Product
                </a>
                <a href="<?php echo e(route('admin.products.documents.create', $product->id)); ?>"
                   class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <i class="fas fa-plus mr-2"></i>
                    Add New Document
                </a>
            </div>
        </div>

        <!-- Documents by Category -->
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryKey => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $categoryDocs = $documents->where('category', $categoryKey)->where('is_active', true);
            ?>
            
            <?php if($categoryDocs->count() > 0): ?>
            <div class="mb-8">
                <h3 class="text-lg font-medium text-gray-900 mb-4"><?php echo e($categoryName); ?></h3>
                
                <div class="bg-white shadow overflow-hidden sm:rounded-md">
                    <ul class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $categoryDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="px-4 py-4 sm:px-6 hover:bg-gray-50">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 mr-4">
                                            <i class="fas fa-file-pdf text-red-500 text-2xl"></i>
                                        </div>
                                        <div class="flex-1">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo e($document->title); ?>

                                            </div>
                                            <div class="text-sm text-gray-500">
                                                <?php echo e($document->file_name); ?> • 
                                                <?php echo e(round($document->file_size / 1024, 2)); ?> KB
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-4">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php echo e($document->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                            <?php echo e($document->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                        <div class="flex space-x-2">
                                            <a href="<?php echo e(route('admin.products.documents.edit', [$product->id, $document->id])); ?>"
                                               class="text-blue-600 hover:text-blue-900">
                                                Edit
                                            </a>
                                            <form action="<?php echo e(route('admin.products.documents.destroy', [$product->id, $document->id])); ?>" 
                                                  method="POST" 
                                                  onsubmit="return confirm('Delete this document?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($documents->count() === 0): ?>
        <div class="text-center py-12">
            <i class="fas fa-file-pdf text-gray-400 text-5xl mb-4"></i>
            <h3 class="text-lg font-medium text-gray-900 mb-2">No documents yet</h3>
            <p class="text-gray-500 mb-6">Get started by uploading your first document.</p>
            <a href="<?php echo e(route('admin.products.documents.create', $product->id)); ?>"
               class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <i class="fas fa-upload mr-2"></i>
                Upload First Document
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/products/documents/index.blade.php ENDPATH**/ ?>