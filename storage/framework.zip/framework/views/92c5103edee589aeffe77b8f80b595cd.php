<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <title><?php echo $__env->yieldContent('title', 'Genenomedx'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/custom.css', 'resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="relative">

  
  <header class="w-full" x-data="{ mobileMenuOpen: false }">

        
        <div class="w-full flex items-center justify-between px-4 md:px-12 py-3 md:py-5 bg-white">

          
<div class="flex items-center space-x-3">
    <div class="gp-logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Genomedx logo" 
                 style="width: auto; height: 55px; max-width: none !important;">
        </a>
    </div>
</div>

            
            <div class="hidden lg:flex items-center space-x-4 xl:space-x-6">

                

                
                <div class="flex items-center space-x-3">
                    <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($social->url); ?>"
                           target="_blank"
                           class="w-8 h-8 xl:w-9 xl:h-9 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm xl:text-base header-small-text">
                            <i class="<?php echo e($social->icon); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="flex items-center text-blue-600 font-medium header-small-text">
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                    <span class="mx-1 text-gray-500">/</span>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                </div>

                <div class="flex items-center header-small-text">
                    <?php $__currentLoopData = $flags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $flag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/flags/'.$flag->image)); ?>" class="w-6 xl:w-7 mx-1">
                        <?php if($index < count($flags) - 1): ?>
                            <span>/</span>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
<div x-data="{
    query: '',
    suggestions: [],
    showSuggestions: false,
    
    async searchSuggestions() {
        if (this.query.length < 2) {
            this.suggestions = [];
            return;
        }
        
        try {
            const response = await fetch(`<?php echo e(route('products.search.suggestions')); ?>?query=${this.query}`);
            const data = await response.json();
            this.suggestions = data;
            this.showSuggestions = true;
        } catch (error) {
            console.error('Search error:', error);
        }
    }
}" 
class="relative header-small-text">
    
    <form action="<?php echo e(route('products.search')); ?>" method="GET" class="flex items-center space-x-2">
        <div class="relative">
            <input 
                type="text" 
                name="query" 
                x-model="query"
                @input.debounce.300ms="searchSuggestions()"
                @focus="if(suggestions.length) showSuggestions = true"
                @blur="setTimeout(() => showSuggestions = false, 200)"
                placeholder="Search products..." 
                class="border rounded px-2 py-1 text-sm w-32 xl:w-40" 
                required
                autocomplete="off">
            
            
            <div x-show="showSuggestions && suggestions.length > 0" 
                 x-transition
                 x-cloak
                 class="absolute top-full left-0 right-0 bg-white border rounded-b shadow-lg z-50 mt-1 max-h-60 overflow-y-auto">
                
                <template x-for="item in suggestions" :key="item.id + item.type">
                    <a :href="item.url" 
                       class="block px-3 py-2 hover:bg-gray-100 border-b last:border-b-0">
                        <div class="font-medium" x-text="item.name"></div>
                        <div class="text-xs text-gray-500" x-text="item.type"></div>
                    </a>
                </template>
            </div>
        </div>
        
        <button type="submit" class="w-8 h-8 xl:w-9 xl:h-9 flex items-center justify-center bg-blue-600 text-white rounded">
            🔍
        </button>
    </form>
</div>
            </div>

            
            <button @click="mobileMenuOpen = !mobileMenuOpen" 
                    class="lg:hidden text-blue-700 text-2xl p-2 focus:outline-none z-50">
                <i class="fas" :class="mobileMenuOpen ? 'fa-times' : 'fa-bars'"></i>
            </button>

        </div>

        
        <div class="hidden lg:block w-full bg-white shadow py-3 relative z-40">
            <nav class="flex flex-nowrap justify-center gap-6 xl:gap-8 text-blue-700 font-semibold text-base xl:text-lg overflow-x-auto px-4">
                <?php $__currentLoopData = $menus->where('parent_id', null)->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($menu->name === 'Products'): ?>
                        
                        <div class="static products-mega-menu" x-data="{ 
                            open: false,
                            selectedCompany: null
                        }">
                            
                            
                            <button class="hover:text-blue-900 font-semibold whitespace-nowrap py-2 relative z-50"
                                @click="open = !open" 
                                @mouseenter="open = true"
                                @keydown.escape.window="open = false; selectedCompany = null;">
                                Products
                            </button>

                            
                            <div x-show="open" 
                                x-transition
                                x-cloak
                                @mouseenter="open = true"
                                @mouseleave="open = false"
                                class="mega-dropdown absolute left-1/2 -translate-x-1/2 top-full mt-0 w-[600px] max-w-[90vw] bg-white border rounded-b-lg shadow-2xl z-50 overflow-hidden"
                                style="margin-top: 2px !important;">
                                
                                <div class="flex min-h-[400px]">
                                    
                                    
                                    <div class="w-1/3 border-r bg-gray-50 p-6 overflow-y-auto" style="max-height: 70vh;">
                                        <h3 class="text-xl font-bold text-gray-800 mb-6">Select Company</h3>
                                        
                                        <div class="space-y-2">
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <button 
                                                    @click="selectedCompany = <?php echo e($company->id); ?>"
                                                    @mouseenter="selectedCompany = <?php echo e($company->id); ?>"
                                                    :class="{
                                                        'bg-blue-600 text-white': selectedCompany == <?php echo e($company->id); ?>,
                                                        'hover:bg-blue-100': selectedCompany != <?php echo e($company->id); ?>

                                                    }"
                                                    class="w-full text-left p-4 rounded-lg transition-all duration-200 flex items-center justify-between">
                                                    
                                                    <div>
                                                        <div class="font-semibold"><?php echo e($company->name); ?></div>
                                                        <div class="text-sm text-gray-600 mt-1">
                                                            <?php echo e($company->active_product_groups_count); ?> product groups
                                                        </div>
                                                    </div>
                                                    
                                                    <i class="fas fa-chevron-right text-sm"></i>
                                                </button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="w-2/3 p-6 overflow-y-auto" style="max-height: 70vh;">
                                        <template x-if="selectedCompany">
                                            <div>
                                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div x-show="selectedCompany == <?php echo e($company->id); ?>">
                                                        <div class="flex items-center justify-between mb-6">
                                                            <h3 class="text-2xl font-bold text-gray-800">
                                                                <?php echo e($company->name); ?> Products
                                                            </h3>
                                                            <a href="<?php echo e(route('companies.show', $company)); ?>" 
                                                               class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                                                                View All →
                                                            </a>
                                                        </div>
                                                        
                                                        <?php if($company->activeProductGroups->count() > 0): ?>
                                                            <div class="grid grid-cols-1 gap-3">
                                                                <?php $__currentLoopData = $company->activeProductGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <a href="<?php echo e(route('products.index', $group->slug)); ?>"
                                                                       class="flex items-center justify-between hover:text-blue-600 transition-all duration-200 group hover:bg-blue-50 p-4 rounded-lg">
                                                                        
                                                                        <div class="flex-grow min-w-0 mr-8">
                                                                            <div class="text-lg font-semibold text-gray-800 group-hover:text-blue-600 whitespace-nowrap overflow-hidden text-ellipsis">
                                                                                <?php echo e($group->name); ?>

                                                                            </div>
                                                                            <div class="text-sm text-gray-600 mt-1">
                                                                                <?php echo e($group->products_count); ?> products
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <?php if($group->image || $group->icon || $group->image_path): ?>
                                                                            <?php
                                                                                $path = $group->image ?? $group->icon ?? $group->image_path;
                                                                                $isAsset = str_contains($path, 'assets/');
                                                                            ?>
                                                                            <div class="w-12 h-12 flex-shrink-0">
                                                                                <img src="<?php echo e($isAsset ? asset($path) : asset('storage/' . $path)); ?>" 
                                                                                     alt="<?php echo e($group->name); ?>"
                                                                                     class="w-full h-full object-contain">
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </a>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="text-center py-12 text-gray-500">
                                                                <div class="text-4xl mb-3">📦</div>
                                                                <div class="text-lg">No product groups available</div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </template>
                                        
                                        
                                        <template x-if="!selectedCompany">
                                            <div class="h-full flex flex-col items-center justify-center text-gray-500">
                                                <div class="text-5xl mb-4">🏢</div>
                                                <h3 class="text-2xl font-bold mb-2">Select a Company</h3>
                                                <p class="text-gray-600">Choose a company from the left to view their products</p>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        
                        <div class="relative" x-data="{ open: false }">
                            <a href="<?php echo e($menu->url ?? '#'); ?>" 
                               class="hover:text-blue-900 whitespace-nowrap py-2 block">
                               <?php echo e($menu->name); ?>

                            </a>

                            <?php if($menu->children->count() > 0): ?>
                                <div x-show="open" x-transition
                                     class="absolute left-0 top-full mt-2 w-56 bg-white border rounded-lg shadow-lg z-50 py-2">
                                    <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($child->url ?? '#'); ?>" 
                                           class="block px-5 py-3 text-gray-700 hover:text-blue-600 hover:bg-gray-50 whitespace-nowrap">
                                            <?php echo e($child->name); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        </div>

        
        <div x-show="mobileMenuOpen" 
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 transform translate-x-full"
             x-transition:enter-end="opacity-100 transform translate-x-0"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 transform translate-x-0"
             x-transition:leave-end="opacity-0 transform translate-x-full"
             @click.away="mobileMenuOpen = false"
             class="lg:hidden fixed inset-0 bg-white z-40 overflow-y-auto pt-20"
             style="display: none;">
            
            <div class="px-6 py-6 space-y-6">
                
                
                <form action="<?php echo e(route('products.search')); ?>" method="GET" class="flex items-center space-x-2 pb-4 border-b">
                    <input type="text" name="query" placeholder="Search product..." class="border rounded px-3 py-2 flex-1" required>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
                        🔍
                    </button>
                </form>

                
                <nav class="space-y-4">
                    <?php $__currentLoopData = $menus->where('parent_id', null)->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($menu->name === 'Products'): ?>
                            <?php
                                $productGroups = \App\Models\ProductGroup::withCount('products')
                                    ->orderBy('position')
                                    ->get();
                            ?>
                            
                            <div x-data="{ productsOpen: false }">
                                <button @click="productsOpen = !productsOpen" 
                                        class="w-full flex items-center justify-between text-blue-700 font-semibold text-lg py-2">
                                    Products
                                    <i class="fas fa-chevron-down transition-transform" :class="productsOpen && 'rotate-180'"></i>
                                </button>
                                
                                <div x-show="productsOpen" x-collapse class="pl-4 mt-2 space-y-2">
                                    <?php $__currentLoopData = $productGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('products.index', $group->slug)); ?>"
                                           class="block py-2 text-gray-700 hover:text-blue-600">
                                            <?php echo e($group->name); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div x-data="{ submenuOpen: false }">
                                <?php if($menu->children->count() > 0): ?>
                                    <button @click="submenuOpen = !submenuOpen" 
                                            class="w-full flex items-center justify-between text-blue-700 font-semibold text-lg py-2">
                                        <?php echo e($menu->name); ?>

                                        <i class="fas fa-chevron-down transition-transform" :class="submenuOpen && 'rotate-180'"></i>
                                    </button>
                                    
                                    <div x-show="submenuOpen" x-collapse class="pl-4 mt-2 space-y-2">
                                        <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e($child->url ?? '#'); ?>" 
                                               class="block py-2 text-gray-700 hover:text-blue-600">
                                                <?php echo e($child->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <a href="<?php echo e($menu->url ?? '#'); ?>" 
                                       class="block text-blue-700 font-semibold text-lg py-2">
                                        <?php echo e($menu->name); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>

                
                <div class="pt-4 border-t space-y-4">
                    
                    
                    <div class="flex items-center space-x-4">
                        <a href="<?php echo e(route('login')); ?>" class="text-blue-600 font-medium">Login</a>
                        <span class="text-gray-500">/</span>
                        <a href="<?php echo e(route('register')); ?>" class="text-blue-600 font-medium">Register</a>
                    </div>

                    
                    <div class="flex items-center space-x-3">
                        <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social->url); ?>"
                               target="_blank"
                               class="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white text-xl">
                                <i class="<?php echo e($social->icon); ?>"></i>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    
                    <div class="flex items-center space-x-2">
                        <?php $__currentLoopData = $flags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $flag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/flags/'.$flag->image)); ?>" class="w-8">
                            <?php if($index < count($flags) - 1): ?>
                                <span>/</span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>

    </header>

    
    <main class="header-spacer pt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>



    
<section class="molecular-diagnostics-section bg-gray-50 py-8 sm:py-12 md:py-16">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header Section -->
        <div class="text-center mb-8 sm:mb-10 md:mb-12">
            <h1 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-800 mb-4 sm:mb-5 md:mb-6 px-2">
                Molecular diagnostics for your routine
            </h1>
            <p class="text-base sm:text-lg text-gray-600 max-w-4xl mx-auto mb-3 sm:mb-4 px-4">
                GeneProof is the biotechnological company providing customers with technologically advanced solutions in the field of molecular <em>in vitro</em> diagnostics of serious infections and genetic diseases.
            </p>
        </div>

        <!-- Company Info -->
        <div class="text-center mb-6 sm:mb-8 px-4">
            <p class="text-sm sm:text-base text-gray-700 mb-3 sm:mb-4">
                The company was founded in 2005 in the Czech Republic, a member of the European Union.
            </p>
            <p class="text-sm sm:text-base text-gray-700">
                In 2022, GeneProof merged with American Laboratory Products Company to create global market leader in the diagnostic product market. GeneProof, partnered with ALPCO, is now a leading Global Diagnostics Company.
            </p>
        </div>

        <!-- CTA Banner -->
        <div class="relative rounded-lg overflow-hidden shadow-xl" style="background: linear-gradient(135deg, #4A90E2 0%, #357ABD 100%);">
            <div class="absolute inset-0 opacity-20" style="background-image: url('data:image/svg+xml,%3Csvg width=\"100\" height=\"100\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"%23ffffff\" fill-opacity=\"0.1\"%3E%3Crect x=\"10\" y=\"10\" width=\"15\" height=\"60\" rx=\"2\"/%3E%3Crect x=\"30\" y=\"20\" width=\"15\" height=\"50\" rx=\"2\"/%3E%3Crect x=\"50\" y=\"15\" width=\"15\" height=\"55\" rx=\"2\"/%3E%3Crect x=\"70\" y=\"25\" width=\"15\" height=\"45\" rx=\"2\"/%3E%3C/g%3E%3C/svg%3E'); background-size: 150px 150px; background-repeat: repeat;"></div>
            
            <div class="relative z-10 flex flex-col md:flex-row items-center justify-between py-10 sm:py-12 md:py-14 lg:py-16 px-4 sm:px-6 md:px-10 lg:px-16">
                <div class="text-white mb-6 sm:mb-8 md:mb-0 text-center md:text-left">
                    <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-1 sm:mb-2">Wide portfolio</h2>
                    <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold">of PCR kits</h2>
                </div>
                
                <a href="#" class="cta-button bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-base sm:text-lg px-6 sm:px-8 md:px-10 py-3 sm:py-4 rounded transition duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1 whitespace-nowrap">
                    GO TO PRODUCTS
                </a>
            </div>
        </div>
    </div>
</section>


<!-- Why to Choose GeneProof Section -->
<section class="why-choose-section bg-white py-12 sm:py-16 md:py-20">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Title -->
        <div class="text-center mb-12 sm:mb-16">
            <h2 class="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-700">
                Why to choose GeneProof?
            </h2>
        </div>

        <!-- Features Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 md:gap-12 mb-12 sm:mb-16 md:mb-20">
            <!-- Feature 1: Highest Quality -->
            <div class="text-center">
                <div class="flex justify-center mb-6">
                    <div class="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-blue-500 flex items-center justify-center">
                        <svg class="w-12 h-12 sm:w-14 sm:h-14 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>
                        </svg>
                    </div>
                </div>
                <h3 class="text-xl sm:text-2xl font-bold text-gray-700 mb-4">
                    Highest Quality of Products
                </h3>
                <p class="text-gray-600 mb-4 px-2 sm:px-4">
                    Best possible sensitivity and specificity,<br>
                    Easy-to-Use concept
                </p>
                <a href="#" class="text-gray-700 hover:text-blue-600 font-semibold border-b-2 border-gray-700 hover:border-blue-600 transition duration-300 inline-block">
                    Read more
                </a>
            </div>

            <!-- Feature 2: Customer Support -->
            <div class="text-center">
                <div class="flex justify-center mb-6">
                    <div class="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-blue-500 flex items-center justify-center">
                        <svg class="w-12 h-12 sm:w-14 sm:h-14 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                </div>
                <h3 class="text-xl sm:text-2xl font-bold text-gray-700 mb-4">
                    Customer Support
                </h3>
                <p class="text-gray-600 mb-4 px-2 sm:px-4">
                    Experts on the line, professional consultation
                </p>
                <a href="#" class="text-gray-700 hover:text-blue-600 font-semibold border-b-2 border-gray-700 hover:border-blue-600 transition duration-300 inline-block">
                    Read more
                </a>
            </div>

            <!-- Feature 3: IVD Regulatory Compliance -->
            <div class="text-center">
                <div class="flex justify-center mb-6">
                    <div class="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-blue-500 flex items-center justify-center">
                        <svg class="w-12 h-12 sm:w-14 sm:h-14 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                        </svg>
                    </div>
                </div>
                <h3 class="text-xl sm:text-2xl font-bold text-gray-700 mb-4">
                    IVD Regulatory Compliance
                </h3>
                <p class="text-gray-600 mb-4 px-2 sm:px-4">
                    All products CE IVD certified, GeneProof<br>
                    complies with IVDR
                </p>
                <a href="#" class="text-gray-700 hover:text-blue-600 font-semibold border-b-2 border-gray-700 hover:border-blue-600 transition duration-300 inline-block">
                    Read more
                </a>
            </div>
        </div>

        <!-- Worldwide Distributors Banner -->
        <div class="relative rounded-lg overflow-hidden shadow-xl" style="background: linear-gradient(135deg, #2B7DB8 0%, #1E5A8E 100%);">
            <!-- World Map Background -->
            <div class="absolute inset-0 opacity-30" style="background-image: url('data:image/svg+xml,%3Csvg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000 400\"%3E%3Cpath fill=\"%23ffffff\" d=\"M100,100 Q150,80 200,100 T300,100 Q350,120 400,100 T500,100 M600,150 Q650,130 700,150 T800,150 M200,200 Q250,180 300,200 T400,200 M100,250 Q150,230 200,250 T300,250 M700,200 Q750,180 800,200 T900,200 M500,280 Q550,260 600,280 T700,280\"%3E%3C/path%3E%3C/svg%3E'); background-size: cover; background-position: center;"></div>
            
            <div class="relative z-10 flex flex-col md:flex-row items-center justify-between py-12 sm:py-14 md:py-16 lg:py-20 px-4 sm:px-6 md:px-10 lg:px-16">
                <div class="text-white mb-8 md:mb-0 text-center md:text-left">
                    <h2 class="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-1 sm:mb-2">Worldwide</h2>
                    <h2 class="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-1 sm:mb-2">network of</h2>
                    <h2 class="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold">distributors</h2>
                </div>
                
                <a href="#" class="distributor-cta-button bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-bold text-base sm:text-lg md:text-xl px-8 sm:px-10 md:px-12 py-4 sm:py-5 rounded transition duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                    FIND YOUR LOCAL<br>DISTRIBUTOR
                </a>
            </div>
        </div>
    </div>
</section>








<!-- Dynamic News Section -->
<section class="py-16 md:py-20 lg:py-24 bg-white">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Header -->
        <div class="text-center mb-12 md:mb-16">
            <span class="inline-block px-4 py-1 bg-blue-100 text-blue-700 text-sm font-semibold rounded-full mb-4">
                Latest Updates
            </span>
            <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
                News & Events
            </h2>
            <p class="text-gray-600 max-w-2xl mx-auto text-lg">
                Stay updated with our latest achievements, events, and announcements
            </p>
        </div>

        <?php if($latestNews->count() > 0): ?>
            <!-- News Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                <?php $__currentLoopData = $latestNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="group relative bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
                        <!-- Image Container -->
                        <div class="relative h-64 overflow-hidden">
                            <?php if($news->image): ?>
                                <img src="<?php echo e(asset('storage/' . $news->image)); ?>" 
                                     alt="<?php echo e($news->title); ?>"
                                     class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                            <?php else: ?>
                                <div class="w-full h-full bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center">
                                    <i class="fas fa-newspaper text-gray-300 text-6xl"></i>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Category Badge -->
                            <div class="absolute top-4 left-4">
                                <span class="px-3 py-1 text-xs font-semibold text-white rounded-full <?php echo e($news->categoryColor); ?> shadow-lg">
                                    <?php echo e($news->categoryLabel); ?>

                                </span>
                            </div>
                            
                            <!-- Date Overlay -->
                            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                                <time class="text-white text-sm font-medium">
                                    <i class="fas fa-calendar-alt mr-2"></i>
                                    <?php echo e($news->published_date->format('d M, Y')); ?>

                                </time>
                            </div>
                        </div>

                        <!-- Content -->
                        <div class="p-6 md:p-8">
                            <h3 class="text-xl md:text-2xl font-bold text-gray-800 mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                                <a href="<?php echo e(route('news.show', $news)); ?>" class="hover:no-underline">
                                    <?php echo e($news->title); ?>

                                </a>
                            </h3>
                            
                            <?php if($news->excerpt): ?>
                                <p class="text-gray-600 mb-4 line-clamp-3">
                                    <?php echo e($news->excerpt); ?>

                                </p>
                            <?php endif; ?>

                            <!-- Read More Button -->
                            <div class="pt-4 border-t border-gray-100">
                                <a href="<?php echo e(route('news.show', $news)); ?>" 
                                   class="inline-flex items-center text-blue-600 font-semibold group-hover:text-blue-700 transition-colors">
                                    Read Full Story
                                    <i class="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
                                </a>
                            </div>
                        </div>

                        <!-- Hover Effect Overlay -->
                        <div class="absolute inset-0 border-2 border-transparent group-hover:border-blue-500 rounded-2xl transition-colors duration-300 pointer-events-none"></div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- View All Button -->
            <div class="text-center mt-12 md:mt-16">
                <a href="<?php echo e(route('news.index')); ?>" 
                   class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                    <span>View All News & Events</span>
                    <i class="fas fa-arrow-right ml-3"></i>
                </a>
            </div>
        <?php else: ?>
            <!-- Empty State -->
            <div class="text-center py-12">
                <div class="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-6">
                    <i class="fas fa-newspaper text-blue-600 text-3xl"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">No News Yet</h3>
                <p class="text-gray-600 mb-6">Check back later for updates and announcements</p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('admin.news.create')); ?>" 
                       class="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                        <i class="fas fa-plus mr-2"></i> Add First News
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Styles for line-clamp -->
<style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .line-clamp-3 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style>

<!-- Styles for line-clamp -->
<style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .line-clamp-3 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style>




<!-- Dynamic Product Groups Section -->
<section class="geneproof-products-section bg-gray-100 py-12 sm:py-16 md:py-20">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Title -->
        <div class="text-center mb-10 sm:mb-12 md:mb-16">
            <h2 class="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-700">
                GenomeDX Products
            </h2>
        </div>

        <!-- Products Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 max-w-7xl mx-auto">

            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.index', $group->slug)); ?>" 
                   class="product-card bg-white rounded-lg shadow-md hover:shadow-xl transition duration-300 p-6 sm:p-8 flex items-center space-x-4 sm:space-x-6 group">

                    <!-- Icon -->
                    <div class="flex-shrink-0">
                        <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-3 flex items-center justify-center 
                                    group-hover:scale-110 transition duration-300"
                             style="border-color: <?php echo e($group->colorHex()); ?>;">
                            <?php if($group->icon): ?>
                                <img src="<?php echo e(asset('storage/'.$group->icon)); ?>" alt="<?php echo e($group->name); ?>" class="w-8 h-8 sm:w-10 sm:h-10">
                            <?php else: ?>
                                <svg class="w-8 h-8 sm:w-10 sm:h-10 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                                </svg>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Name -->
                    <div>
                        <h3 class="text-lg sm:text-xl font-bold" 
                            style="color: <?php echo e($group->colorHex()); ?>">
                            <?php echo e($group->name); ?>

                        </h3>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>



<!-- GenomeDX Professional Footer -->
<footer class="bg-gray-900 text-white">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <!-- Company Information -->
            <div class="space-y-4">
                <div>
                    <h3 class="text-xl font-bold text-white mb-3">
                        GenomeDX Corporation
                    </h3>
                    <address class="not-italic text-gray-300 text-sm leading-relaxed">
                        205/1 (1st Floor)<br>
                        Dr.Kudrat-E-Khuda Road<br>
                        Dhaka-1205, Bangladesh
                    </address>
                </div>
                
                <div class="space-y-2">
                    <div class="flex items-center space-x-2">
                        <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"/>
                        </svg>
                        <a href="mailto:genomedxcorporation@gmail.com" class="text-sm text-gray-300 hover:text-white transition">
                            genomedxcorporation@gmail.com
                        </a>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20 15.5c-1.2 0-2.3-.3-3.3-.8-.1-.1-.3-.1-.4 0l-2.5 1.5c-2.1-1.2-3.8-2.9-5-5l1.5-2.5c.1-.1.1-.3 0-.4-.5-1-.8-2.1-.8-3.3C9 4 10 3 11.2 3h1.5c1.1 0 2 .9 2 2 0 2.6.9 5 2.5 6.9.4.5.8 1 1.2 1.5.4.5.7 1 .9 1.5.3.8-.2 1.6-1 1.6h-1.5z"/>
                        </svg>
                        <a href="tel:+88029664349" class="text-sm text-gray-300 hover:text-white transition">
                            +880 2966 4349
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="space-y-4">
                <h4 class="text-lg font-semibold text-white mb-3">Quick Links</h4>
                <ul class="space-y-2">
                    <li>
                        <a href="#" class="text-sm text-gray-300 hover:text-white transition">
                            About Us
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-sm text-gray-300 hover:text-white transition">
                            Our Services
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-sm text-gray-300 hover:text-white transition">
                            Contact Us
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-sm text-gray-300 hover:text-white transition">
                            Privacy Policy
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-sm text-gray-300 hover:text-white transition">
                            Terms of Service
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Contact & Social -->
            <div class="space-y-4">
                <h4 class="text-lg font-semibold text-white mb-3">Get in Touch</h4>
                <p class="text-sm text-gray-300 mb-4">
                    Have questions about our genomic services? Contact our team for expert consultation.
                </p>
                
                <div class="flex space-x-3">
                    <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" 
                       class="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition">
                        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                    </a>
                    
                    <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" 
                       class="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-700 transition">
                        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                        </svg>
                    </a>
                    
                    <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" 
                       class="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition">
                        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Bottom Bar -->
        <div class="border-t border-gray-800 mt-8 pt-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="text-sm text-gray-400 mb-4 md:mb-0">
                    © 2024 GenomeDX Corporation. All rights reserved.
                </div>
                
                <div class="flex items-center space-x-4">
                    <a href="https://www.genomedxbd.com" target="_blank" rel="noopener noreferrer" 
                       class="text-sm text-gray-300 hover:text-white transition">
                        www.genomedxbd.com
                    </a>
                    <span class="text-gray-600">|</span>
                    <span class="text-xs text-gray-500">
                        GPS: 41.82183, -0.77329
                    </span>
                </div>
            </div>
        </div>
    </div>
</footer>





</body>
</html>
<?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/front/layouts/app.blade.php ENDPATH**/ ?>