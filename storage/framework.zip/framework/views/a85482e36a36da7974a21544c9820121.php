<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">Frontend Settings</h1>
    
    
    <?php if(session('success')): ?>
        <div class="mb-6 p-4 bg-green-100 text-green-800 rounded-lg border border-green-300">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span><?php echo e(session('success')); ?></span>
            </div>
        </div>
    <?php endif; ?>
    
    
    <?php if(session('error')): ?>
        <div class="mb-6 p-4 bg-red-100 text-red-800 rounded-lg border border-red-300">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span><?php echo e(session('error')); ?></span>
            </div>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="bg-white p-6 rounded-lg shadow-md mb-6 border border-gray-200">
            <h2 class="text-lg font-semibold mb-4 text-gray-800">Product Groups Display</h2>
            
            <div class="mb-4">
                <label class="block text-sm font-medium mb-2 text-gray-700">
                    Show product groups from:
                </label>
                <select name="frontend_company_id" class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">All Companies (Show everything)</option>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->id); ?>" 
                            <?php echo e($selectedCompanyId == $company->id ? 'selected' : ''); ?>>
                            <?php echo e($company->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p class="text-sm text-gray-600 mt-2">
                    <i class="fas fa-info-circle mr-1"></i>
                    Select a company to show only their product groups, or leave empty to show all.
                </p>
            </div>
        </div>
        
        <div class="flex items-center space-x-3">
            <button type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center">
                <i class="fas fa-save mr-2"></i>
                Save Settings
            </button>
            
            <a href="<?php echo e(url('/')); ?>" target="_blank" 
               class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition flex items-center">
                <i class="fas fa-eye mr-2"></i>
                View Frontend
            </a>
        </div>
    </form>
    
    
    <div class="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h3 class="text-md font-semibold mb-2 text-blue-800">
            <i class="fas fa-info-circle mr-2"></i>Current Setting
        </h3>
        <p class="text-gray-700">
            <?php if($selectedCompanyId): ?>
                Currently showing product groups from: 
                <span class="font-semibold text-blue-600">
                    <?php echo e(\App\Models\Company::find($selectedCompanyId)->name ?? 'Selected Company'); ?>

                </span>
            <?php else: ?>
                Currently showing product groups from: 
                <span class="font-semibold text-blue-600">All Companies</span>
            <?php endif; ?>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/shadmansakib/Desktop/geneproof-clone/resources/views/admin/settings/index.blade.php ENDPATH**/ ?>